Write-Host "Enter first number: "
$num1 = Read-Host
Write-Host "Enter operator (+, -, *, /): "
$operator = Read-Host
Write-Host "Enter second number: "
$num2 = Read-Host

switch ($operator) {
    "+" { $result = [math]::Round($num1 + $num2, 2) }
    "-" { $result = [math]::Round($num1 - $num2, 2) }
    "*" { $result = [math]::Round($num1 * $num2, 2) }
    "/" { $result = [math]::Round($num1 / $num2, 2) }
    default { $result = "Invalid operator" }
}

Write-Host "The result is: $result"
Read-Host -Prompt "Press Enter to exit"
